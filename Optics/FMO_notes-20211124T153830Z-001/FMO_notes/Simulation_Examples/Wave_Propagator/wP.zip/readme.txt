you need first to install wxMaxima from http://andrejv.github.io/wxmaxima/ or 

To install this propagator simply extract in a folder and execute 
wP.wxm  in Maxima

wP.wxm reads initialization parameters from:Propagator_ini.txt

